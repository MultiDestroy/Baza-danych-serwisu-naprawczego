﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Osoby
{
    public partial class Form1 : Form
    {
        public string connectionString = @"Data Source=LAPTOP-VMDTVLU7\SQLEXPRESS;Initial Catalog=Serwis naprawczy;Integrated Security = true";
        int ID_osoby =0;

        void GridFill()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("SELECT * FROM Osoby", conn);
                SqlDataReader reader = comm.ExecuteReader();
                DataTable table = new DataTable();
                table.Load(reader);
                tabelaGrid.DataSource = table;
                tabelaGrid.Columns[0].Visible = false;
            }
        }
        void Clear()
        {
            txtAdres.Text = txtEmail.Text = txtImie.Text = txtNazwisko.Text = txtNumer.Text = txtPlec.Text = "";
            ID_osoby = 0;
            btnZapisz.Text = "Zapisz";
            btnUsun.Enabled = false;
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Clear();
            GridFill();
        }

        private void btnZapisz_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("WstawAlboEdytujOsoby", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@ID_osoby", ID_osoby);
                comm.Parameters.AddWithValue("@Imie", txtImie.Text.Trim());
                comm.Parameters.AddWithValue("@Nazwisko", txtNazwisko.Text.Trim());
                comm.Parameters.AddWithValue("@Plec", txtPlec.Text.Trim());
                comm.Parameters.AddWithValue("@Adres", txtAdres.Text.Trim());
                comm.Parameters.AddWithValue("@NumerKontaktowy", txtNumer.Text.Trim());
                comm.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                try {
                    comm.ExecuteNonQuery(); MessageBox.Show("Wykonano"); 
                    } catch { MessageBox.Show("Błąd"); }
                Clear();
                GridFill();
            }
        }
        private void btnAnuluj_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void tabelaGrid_DoubleClick(object sender, EventArgs e)
        {
            if (tabelaGrid.CurrentRow.Index != -1)
            {
                txtImie.Text = tabelaGrid.CurrentRow.Cells[1].Value.ToString();
                txtNazwisko.Text = tabelaGrid.CurrentRow.Cells[2].Value.ToString();
                txtPlec.Text = tabelaGrid.CurrentRow.Cells[3].Value.ToString();
                txtAdres.Text = tabelaGrid.CurrentRow.Cells[4].Value.ToString();
                txtNumer.Text = tabelaGrid.CurrentRow.Cells[5].Value.ToString();
                txtEmail.Text = tabelaGrid.CurrentRow.Cells[6].Value.ToString();
                ID_osoby = Convert.ToInt32(tabelaGrid.CurrentRow.Cells[0].Value.ToString());
                btnZapisz.Text = "Zmień";
                btnUsun.Enabled = true;
            }
        }
        private void btnUsun_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand comm = new SqlCommand("UsunOsoby", conn);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Parameters.AddWithValue("@ID_osoby", ID_osoby);
                try
                {
                    comm.ExecuteNonQuery(); MessageBox.Show("Wykonano");
                }
                catch { MessageBox.Show("Błąd"); }
                Clear();
                GridFill();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
